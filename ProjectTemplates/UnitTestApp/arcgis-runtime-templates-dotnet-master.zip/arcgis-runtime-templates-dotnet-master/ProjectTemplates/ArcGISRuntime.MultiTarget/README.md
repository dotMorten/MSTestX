This folder contains 4 project templates for Multi-Targeting projects:

 - Class Library with simple Map ViewModel that targets net461, UWP, Android and iOS.
 - Xamarin.Forms Class Library with a MapPage and a simple Map ViewModel that targets UWP, Android and iOS.
 - App project that contains net461, UWP, Android and iOS project heads, in addition to multi-targeted Map ViewModel class library
 - App project that contains  UWP, Android and iOS project heads, in addition to multi-targeted Xamarin.Forms MapPage and VM class library
