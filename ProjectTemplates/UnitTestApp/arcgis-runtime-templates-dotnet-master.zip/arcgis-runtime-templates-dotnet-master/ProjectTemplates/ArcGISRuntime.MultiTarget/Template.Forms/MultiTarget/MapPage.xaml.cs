﻿using Xamarin.Forms;

namespace $safeprojectname$
{
    public partial class MapPage : ContentPage
    {
        public MapPage()
        {
            InitializeComponent();
        }

        // Map initialization logic is contained in MapViewModel.cs
    }
}
